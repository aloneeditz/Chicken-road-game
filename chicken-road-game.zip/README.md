# Chicken Road Game
A Phaser + React game where you play as a chicken crossing the road.
